package br.com.funcionario.controle;

public class Cpf {

}
