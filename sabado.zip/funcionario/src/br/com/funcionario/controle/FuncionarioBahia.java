package br.com.funcionario.controle;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.jtecweblojavirtual.entidade.Categoria;
import br.com.jtecweblojavirtual.entidade.Produto;
import br.com.jtecweblojavirtual.persistencia.ProdutoDao;

public class FuncionarioBahia {

}

//@WebServlet(name = "ControleProduto", urlPatterns = {"/cadastrar.html","/buscar.html""/excluir.html","/editar.html","/confirmar.html"})
@WebServlet({ "/ControleProduto", "/cadastrar.html", "/buscar.html", "/excluir.html","/editar.html","/confirmar.html"})
public class FuncionarioBahia extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FuncionarioBahia() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Pegando uma URL que chamou a Servlet
			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/cadastrar.html")) {
				cadastrar(request, response);
			} else if (url.equalsIgnoreCase("/buscar.html")) {
				buscar(request, response);
			}else if(url.equalsIgnoreCase("/excluir.html")) {
				excluir(request, response);
			}else if(url.equalsIgnoreCase("/editar.html")) {
				editar(request, response);
			}else if(url.equalsIgnoreCase("/confirmar.html")) {
				confirmar(request, response);
			}else {
				throw new Exception("URL Inv�lida!!!");
			}
		} catch (Exception e) {
			response.sendRedirect("index.jsp");
			e.printStackTrace();
		}
	}

	protected void cadastrar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nome = request.getParameter("nome");
		// Integer estoque = new Integer(request.getParameter("estoque"));
		// Integer estoque = Integer.pasrseInt("estoque");
		String estoque = request.getParameter("estoque");
		String preco = request.getParameter("preco");
		String validade = request.getParameter("validade");
		String idCategoria = request.getParameter("categoria");

		Produto produto = new Produto();
		Categoria categoria = new Categoria();

		produto.setNome(nome);
		produto.setEstoque(new Integer(estoque));
		produto.setPreco(new Double(preco.replace(',', '.')));
		produto.setValidade(produto.converterDataParaMysql(validade));
		categoria.setIdCategoria(new Integer(idCategoria));

		// Relacionando as Classes Produto com Categoria
		produto.setCategoria(categoria);

		// Gravando os dados no Banco de Dados
		// Populando o Banco de Dados
		ProdutoDao pd = new ProdutoDao();
		try {
			pd.cadastrarProduto(produto);
			request.setAttribute("msg", "<div class='alert alert-success'>Produto Cadastrado com sucesso!!!</div>");
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o cadastrado!!!</div>");
		} finally {
			request.getRequestDispatcher("cadastraProduto.jsp").forward(request, response);
		}

	}

	public void buscar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String nome = request.getParameter("nome");
			ProdutoDao pd = new ProdutoDao();

			List<Produto> lista = pd.buscarProduto(nome);

			if (lista.size() == 0) {
				request.setAttribute("msg", "<div class='alert alert-info'>Nenhum Produto na lista!!!</div>");
			}
			request.setAttribute("nome", nome);
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("buscaProduto.jsp").forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//Capturando o id do Produto
			String idProduto = request.getParameter("id");
			ProdutoDao pd = new ProdutoDao();
			pd.excluirProduto(new Integer(idProduto));
			request.setAttribute("msg", "<div class='alert alert-success'>Produto exclu�do com sucesso!!!</div>");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o exclu�do!!!</div>");
		}finally {
			request.getRequestDispatcher("buscaProduto.jsp").forward(request, response);
		}	
		
	}

	public void editar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//Capturando o id do Produto
			String idProduto = request.getParameter("id");
			ProdutoDao pd = new ProdutoDao();
			Produto produto =  pd.buscarProdutoPorId(new Integer(idProduto));
			
			if(produto == null) {
				request.setAttribute("msg", "<div class='alert alert-info'>Produto n�o encontrado!!!</div>");
				request.getRequestDispatcher("buscaProduto.jsp").forward(request, response);
			}else {
				request.setAttribute("prod", produto);
				request.getRequestDispatcher("editaProduto.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Erro: "+e.getMessage()+"</div>");
			request.getRequestDispatcher("buscaProduto.jsp").forward(request, response);
		}
	}

	public void confirmar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nome = request.getParameter("nome");
		// Integer estoque = new Integer(request.getParameter("estoque"));
		// Integer estoque = Integer.pasrseInt("estoque");
		String estoque = request.getParameter("estoque");
		String preco = request.getParameter("preco");
		String validade = request.getParameter("validade");
		String idCategoria = request.getParameter("categoria");
		//Preciso declarar o id, para atualiza��o no banco de dados
		String idProduto = request.getParameter("id");

		Produto produto = new Produto();
		Categoria categoria = new Categoria();

		produto.setNome(nome);
		produto.setEstoque(new Integer(estoque));
		produto.setPreco(new Double(preco.replace(',', '.')));
		produto.setValidade(produto.converterDataParaMysql(validade));
		categoria.setIdCategoria(new Integer(idCategoria));
		produto.setIdProduto(new Integer(idProduto));

		// Relacionando as Classes Produto com Categoria
		produto.setCategoria(categoria);

		// Gravando os dados no Banco de Dados
		// Populando o Banco de Dados
		ProdutoDao pd = new ProdutoDao();
		try {
			pd.atualizarProduto(produto);
			request.setAttribute("msg", "<div class='alert alert-success'>Produto Atualizado com sucesso!!!</div>");
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Produto n�o atualizado!!!</div>");
		} finally {
			request.getRequestDispatcher("buscaProduto.jsp").forward(request, response);
		}
	}

}
