package br.com.funcionariobahia.persistence;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweblojavirtual.entidade.Categoria;
import br.com.jtecweblojavirtual.entidade.Produto;
import br.com.jtecweblojavirtual.persistencia.Dao;

public class ProdutoDao extends Dao {

	// Criando o m�todo de inser��o Dao
	public void cadastrarProduto(Produto produto) throws SQLException {
		open();
		String sql = "insert into produto(nome,estoque,preco,validade,id_categoria)" + "values(?,?,?,?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, .getNome());
		stmt.setInt(2, funcionario.getEstoque());
		stmt.setDouble(3, funcionario.getPreco());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, df.format(funcionario.getValidade()));
		stmt.setInt(5, funcionario.getCargo().getIdCargo());
		stmt.execute();
		close();
	}

	// Criando o m�todo de Atualiza��o Dao
	public void atualizarProduto(Produto produto) throws SQLException {
		open();
		String sql = "UPDATE cargo set nome = ?, estoque = ?, preco = ?,"
				+ "validade = ?, id_cargo = ? where idFuncionario = ?";
		
		
		
		stmt = con.prepareStatement(sql);
		stmt.setString(1, produto.getNome());
		stmt.setInt(2, produto.getEstoque());
		stmt.setDouble(3, produto.getPreco());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, df.format(produto.getValidade()));
		stmt.setInt(5, produto.getCargo().getIdCargo());
		stmt.setInt(6, produto.getIdProduto());
		stmt.executeUpdate();
		close();
	}

	// Criando o m�todo de Atualiza��o Dao
	public void excluirProduto(int idProduto) throws SQLException {
		open();
		String sql = "delete from produto where idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idProduto);
		stmt.execute();
		close();
	}
		
	public List<Produto> buscarProduto(String nomeProduto) throws SQLException{
		open();
		String sql = "select * from produto inner join categoria "
				+ " on produto.id_categoria = categoria.idcategoria where nome like ?"; 
		stmt = con.prepareStatement(sql);
		stmt.setString(1, nomeProduto+"%");
		
		//Objeto que recebe a lista completa do stmt, para sele��o dos dados		
		rs = stmt.executeQuery();
		List<Produto> lista = new ArrayList<Produto>();
		
		while(rs.next()) {
			Produto produto = new Produto(rs.getInt("idProduto"),
										  rs.getString("nome"),
										  rs.getInt("estoque"),
										  rs.getDouble("preco"),
										  rs.getDate("validade"));
			Categoria categoria = new Categoria(rs.getInt("idcategoria"), 
												rs.getString("nomecategoria"));
			produto.setCategoria(categoria);
			
			lista.add(produto);
		}
		
		close();
		return lista;
	}
	public Produto buscarProdutoPorId(int idProduto) throws SQLException {
		open();
		String sql = "select * from produto inner join categoria "
				+ " on id_categoria = idcategoria where idproduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idProduto);
		
		Produto produto = null;
		rs = stmt.executeQuery();
		
		if(rs.next()) {
			produto = new Produto(rs.getInt("idProduto"),
					  rs.getString("nome"),
					  rs.getInt("estoque"),
					  rs.getDouble("preco"),
					  rs.getDate("validade"));
			
			Categoria categoria = new Categoria(rs.getInt("idCategoria"), 
												rs.getString("nomeCategoria"));
			produto.setCategoria(categoria);
		}
		close();
		return produto;
	}

}
