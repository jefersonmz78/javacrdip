package br.com.funcionariobahia.persistence;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweblojavirtual.entidade.Categoria;

public class CargoDao extends Dao {
	
	public List<Cargo> listar() throws SQLException{
		open();
		//Preparar a consulta com a Query sql
		String sql = "select * from categoria";
		stmt = con.prepareStatement(sql);
		List<Cargo> lista = new ArrayList<Cargo>();
		
		//Exceutando a query no Banco de Dados e passando a lista para rs
		rs = stmt.executeQuery();
		
		//Vamos usar o while para varrer a lista e popul�-la
		//Enquanto tiver linhas de registro no BD, o rs retorna a lista de dados
		while(rs.next()) {
			//Criando um objeto do tipo Categoria
			Cargo cat = new Cargo();
			cat.setIdCargo(rs.getInt("idCargo"));
			cat.setNomeCargo(rs.getString("nomeCargo"));
			
			//Adicionar o idCargo e o nomeCargo � lista.
			lista.add(cat);
		}
		close();
		return lista;
	}
}
