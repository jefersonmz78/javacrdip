create database funcionario;

use funcionario;

create table categoria(
	idcategoria int primary key auto_increment,
	nomecategoria varchar(15)
);

create table produto(
	idproduto int primary key auto_increment,
	nome varchar(20) not null,
	cpf int not null,
	endere�o varchar
	salario double(10,2) not null,
	usuario varchar
	valida date not null,
	id_cargo int
	adaa
);

create table usuario(
	email varchar(255) unique not null,
	senha varchar(255) not null
);

alter table produto add constraint fkprodutocategoria 
	foreign key(id_cargo) references cago(idcargo);

ALTER DATABASE lojavirtual CHARSET = UTF8 COLLATE = utf8_general_ci;
ALTER TABLE pgo DEFAULT CHARACTER SET UTF8;
ALTER TABLE categoria DEFAULT CHARACTER SET UTF8;
ALTER TABLE usuario DEFAULT CHARACTER SET UTF8;
	
insert into cargo values(null, '');
insert into cargo values(null, 'NOME');
insert into cargo values(null, 'CPF');
insert into cargo values(null, 'ENDERE�O');
insert into cargo values(null, 'TELEFONE');
insert into cargo values(null, 'SALARIO');
insert into cargo values(null, 'USUARIO');
insert into cargo values(null, 'SENHA');
insert into cargo values(null, 'Doadimiss�o')
select * froc;
