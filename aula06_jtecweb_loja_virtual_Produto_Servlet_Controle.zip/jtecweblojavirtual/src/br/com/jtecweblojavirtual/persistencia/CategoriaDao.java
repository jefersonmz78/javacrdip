package br.com.jtecweblojavirtual.persistencia;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweblojavirtual.entidade.Categoria;

public class CategoriaDao extends Dao {
	
	public List<Categoria> listar() throws SQLException{
		open();
		//Preparar a consulta com a Query sql
		String sql = "select * from categoria";
		stmt = con.prepareStatement(sql);
		List<Categoria> lista = new ArrayList<Categoria>();
		
		//Exceutando a query no Banco de Dados e passando a lista para rs
		rs = stmt.executeQuery();
		
		//Vamos usar o while para varrer a lista e popul�-la
		//Enquanto tiver linhas de registro no BD, o rs retorna a lista de dados
		while(rs.next()) {
			//Criando um objeto do tipo Categoria
			Categoria cat = new Categoria();
			cat.setIdCategoria(rs.getInt("idCategoria"));
			cat.setNomeCategoria(rs.getString("nomeCategoria"));
			
			//Adicionar o idCategoria e o nomeCategoria � lista.
			lista.add(cat);
		}
		close();
		return lista;
	}
}
