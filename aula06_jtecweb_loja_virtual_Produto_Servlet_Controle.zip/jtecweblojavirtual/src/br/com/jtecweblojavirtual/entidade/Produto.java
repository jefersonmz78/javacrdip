package br.com.jtecweblojavirtual.entidade;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Produto {
	private Integer idProduto;
	private String nome;
	private Integer estoque;
	private Double preco;
	private Date validade;	
	//Atributo Categoria. Todo atributo tem uma Categoria.
	private Categoria categoria;
	
	public Produto() {
		
	}

	public Produto(Integer idProduto, String nome, Integer estoque, Double preco, Date validade) {
		super();
		this.idProduto = idProduto;
		this.nome = nome;
		this.estoque = estoque;
		this.preco = preco;
		this.validade = validade;
	}

	@Override
	public String toString() {
		return "Produto [idProduto=" + idProduto + ", nome=" + nome + ", estoque=" + estoque + ", preco=" + preco
				+ ", validade=" + validade + ", categoria=" + categoria + "]";
	}

	public Integer getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(Integer idProduto) {
		this.idProduto = idProduto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getEstoque() {
		return estoque;
	}

	public void setEstoque(Integer estoque) {
		this.estoque = estoque;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public Date getValidade() {
		return validade;
	}

	public void setValidade(Date validade) {
		this.validade = validade;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	//M�todo para convers�o de Data para o Banco de Dados
	public Date converterDataParaMysql(String data) {
		//Criando um Array de String para capturar a data
		String dt[] = data.split("/");
		//Instanciando um objeto do tipo GregorianCalendar (Calend�rio Gregoriano)
		//Passando o seu objeto para Calendar, para tratamento da data de acordo com a data do BD
		Calendar calendar = new GregorianCalendar();		
		//       23   / 04   /  1990
		// dt[]   0      1        2
		calendar.set(Integer.parseInt(dt[2]), 
					 Integer.parseInt(dt[1])-1, 
					 Integer.parseInt(dt[0]));
		return calendar.getTime();		
	}
	
}
