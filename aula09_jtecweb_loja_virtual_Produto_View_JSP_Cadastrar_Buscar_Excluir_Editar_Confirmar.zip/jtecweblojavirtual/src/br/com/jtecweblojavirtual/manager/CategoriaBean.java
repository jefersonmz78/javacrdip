package br.com.jtecweblojavirtual.manager;

import java.util.List;

import br.com.jtecweblojavirtual.entidade.Categoria;
import br.com.jtecweblojavirtual.persistencia.CategoriaDao;

public class CategoriaBean {
	
	private List<Categoria> listaCategoria;
	
	public CategoriaBean() {
		try {
			this.listaCategoria = new CategoriaDao().listar();
		} catch (Exception e) {
			
		}
	}

	public List<Categoria> getListaCategoria() {
		return listaCategoria;
	}

	public void setListaCategoria(List<Categoria> listaCategoria) {
		this.listaCategoria = listaCategoria;
	}
	
}
