package br.com.jtecweblojavirtual.controle;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.jtecweblojavirtual.entidade.Login;
import br.com.jtecweblojavirtual.persistencia.LoginDao;

//@WebServlet(name = "/ControleLogin", urlPatterns = {"/cadastrarLogin.html"})
@WebServlet({ "/ControleLogin", "/cadastrarLogin.html","acessarLogin.html" })
public class ControleLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ControleLogin() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		execute(request, response);
	}

	protected void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String url = request.getServletPath();
			if (url.equalsIgnoreCase("/cadastrarLogin.html")) {
				cadastrarLogin(request, response);
			}
		} catch (Exception e) {

		}
	}

	protected void cadastrarLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Capturando as string's da tela de login, dos input's
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");

		// Instanciando um objeto do tipo Login e passar os dados para os m�todos set's
		Login login = new Login();
		login.setEmail(email);
		login.setSenha(senha);

		// Instanciando um Objeto do Tipo LoginDao
		LoginDao dao = new LoginDao();
		try {
			dao.cadastrarLogin(login);
			request.setAttribute("msg", "<div class='alert alert-success'>Login Cadastrado!</div>");
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("msg", "<div class='alert alert-danger'>Login n�o Cadastrado!</div>");
		} finally {
			request.getRequestDispatcher("cadastraProduto.jsp").forward(request, response);
		}

	}

	protected void acessarLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			//Capturando os dados do formul�rio
			String email = request.getParameter("email");
			String senha = request.getParameter("senha");
			
			Login login = new LoginDao().consultarLogin(email, senha);
			
			if(login != null) {
				request.getSession().setAttribute("usuarioLogado", login.getEmail());
				response.sendRedirect("cadastraProduto.jsp");
			}else {
				request.setAttribute("msg", "<div class='alert alert-danger'>Erro no Login!</div>");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "Erro "+e.getMessage());
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

}
