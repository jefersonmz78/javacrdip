package br.com.jtecweblojavirtual.persistencia;

import java.sql.SQLException;

import br.com.jtecweblojavirtual.entidade.Login;

public class LoginDao extends Dao {
	
	public void cadastrarLogin(Login login) throws SQLException {
		open();
		String sql = "insert into login(email, senha)values(?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, login.getEmail());
		stmt.setString(2, login.getSenha());
		stmt.execute();
		close();
	}
	public Login consultarLogin(String email, String senha) throws SQLException {
		open();
		String sql = "select * from login where email = ? and senha = ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		stmt.setString(2, senha);
		
		rs = stmt.executeQuery();
		Login login = null;
		
		if(rs.next()) {
			login = new Login(rs.getString("email"),rs.getString("senha"));
		}
		close();
		return login;
	}
}
