package br.com.jtecweb.persistence;

import java.sql.Connection;
import java.sql.SQLException;

public class TesteDeConexaoDaFabrica {

	public static void main(String[] args) throws SQLException {
		
		Connection con = ConnectionFactory.pegarConexao();
		System.out.println("Conex�o com a f�brica com sucesso!!!");
		con.close();		
	}

}
