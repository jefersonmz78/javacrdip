create database lojavirtualcarrinho;

use lojavirtualcarrinho;

create table produto(
	id serial,
	nome varchar (100),
	descricao varchar (255),
	precoUnitario real,
	imagem varchar (100),
	primary Key(id)
);
insert into produto (nome, descricao, precoUnitario, imagem) values ('afuche', 'prercursao', 1030, 'afuche.jpg');
insert into produto (nome, descricao, precoUnitario, imagem) values ('bateria', 'percursao', 1000, 'bateria.jpg');
insert into produto (nome, descricao, precoUnitario, imagem) values ('sax', 'sopro', 1500, 'sax.jpg');
insert into produto (nome, descricao, precoUnitario, imagem) values ('ektaratenor', 'sopro', 1200, 'ektaratenor.jpg');
insert into produto (nome, descricao, precoUnitario, imagem) values ('violao', 'cordas', 3200, 'violao.jpg');
insert into produto (nome, descricao, precoUnitario, imagem) values ('piano', 'teclas', 12000, 'piano.jpg');