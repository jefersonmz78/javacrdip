package br.com.jtecweblojavirtual.manager;

import java.util.List;

import br.com.funcionariobahia.persistence.CategoriaDao;
import br.com.jtecweblojavirtual.entidade.Categoria;

public class CategoriaBean {
	
	private List<Categoria> listaCategoria;
	
	public CategoriaBean() {
		try {
			this.listaCategoria = new CategoriaDao().listar();
		} catch (Exception e) {
			
		}
	}

	public List<Categoria> getListaCategoria() {
		return listaCategoria;
	}

	public void setListaCategoria(List<Categoria> listaCategoria) {
		this.listaCategoria = listaCategoria;
	}
	
}
