package br.com.jtecweb.controle;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.jtecweb.entidade.Contato;
import br.com.jtecweb.persistence.ContatoDao;

@WebServlet("/AdicionaContato")
public class AdicionaContato extends HttpServlet{
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Objeto para lan�ar Mensagem no navegador da requisi��o
		PrintWriter out = response.getWriter();
		
		//Pegar os dados do formul�rio
		//$nome = $_POST["nome"] no PHP
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String endereco = request.getParameter("endereco");
		
		//Instanciando um objeto do tipo Contato e passando os dados do formul�rio
		//contidos nas vari�veis acima para o m�todo set da Classe Contato
		Contato contato = new Contato();
		contato.setNome(nome);
		contato.setEmail(email);
		contato.setEndereco(endereco);
		
		//Instanciando um Objeto do tipo ContatoDao e passando o objeto Contato para o m�todo
		//de ContatoDao (adicionaContato)
		try {
			ContatoDao dao = new ContatoDao();
			dao.adicionaContato(contato);
			//Imprimindo uma mensagem de sucesso do cadastro
			out.println("<html>");
			out.println("<body>");			
			out.println("Contato "+contato.getNome()+" adicionando com sucesso!!!");
			out.println("</body>");
			out.println("</html>");			
		} catch (Exception e) {
			e.printStackTrace();
			out.println("<html>");
			out.println("<body>");			
			out.println("Contato "+contato.getNome()+" n�o foi adicionado!!!");
			out.println("</body>");
			out.println("</html>");				
		}				
	}
}
