package br.com.funcionariobahia.controle;

public class DataDeAdmissao {

}
//CLASSE FUNCIONARIO
public class Funcionario

Data dataDeAdmissao

 public class Data{  
    int dia;  
    int mes;  
    int ano;  
    public Data(int dia, int mes, int ano){  
      this.dia = dia;  
      this.mes = mes;  
      this.ano = ano;  
    }  
    }  
}
