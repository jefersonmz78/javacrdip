package br.com.funcionariobahia.controle;

public class Cpf {

}
