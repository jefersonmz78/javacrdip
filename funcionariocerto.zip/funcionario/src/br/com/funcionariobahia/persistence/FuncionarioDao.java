package br.com.funcionariobahia.persistence;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweblojavirtual.entidade.Categoria;
import br.com.jtecweblojavirtual.entidade.Produto;
import br.com.jtecweblojavirtual.persistencia.Dao;

public class FuncionarioDao extends Dao {

	// Criando o m�todo de inser��o Dao
	public void cadastrarFuncionario(Funcionario funcionario) throws SQLException {
		open();
		String sql = "insert into produto(nome,estoque,preco,validade,id_categoria)" + "values(?,?,?,?,?)";
		stmt = con.prepareStatement(sql);
		stmt.setString(1,funcionario .getNome());
		stmt.setInt(2, funcionario.getEstoque());
		stmt.setDouble(3, funcionario.getPreco());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		stmt.setString(4, df.format(funcionario.getValidade()));
		stmt.setInt(5, funcionario.getCargo().getIdCargo());
		stmt.execute();
		close();
	}

	// Criando o m�todo de Atualiza��o Dao
	public void atualizarFuncionario(Funcionario funcionario) throws SQLException {
		open();
		String sql = "UPDATE cargo set nome = ?, estoque = ?, preco = ?,"
				+ "validade = ?, id_cargo = ? where idFuncionario = ?";
		
		
		
		stmt = con.prepareStatement(sql);
		stmt.setString(1, funcionario.getNome());
		stmt.setInt(2, funcionario.getCPF());
		stmt.setDouble(3, funcionario.getEndere�o());
		DateFormat df = new SimpleDateFuncionario("yyyy-MM-dd");
		stmt.setString(4, df.format(.getFuncionario()));
		stmt.setInt(5, funcionario.getCargo().getIdCargo());
		stmt.setInt(6, funcionario.getIdProduto());
		stmt.executeUpdate();
		close();
	}

	// Criando o m�todo de Atualiza��o Dao
	public void excluirProduto(int idProduto) throws SQLException {
		open();
		String sql = "delete from produto where idProduto = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idProduto);
		stmt.execute();
		close();
	}
		
	public List<Produto> buscarProduto(String nomeProduto) throws SQLException{
		open();
		String sql = "select * from produto inner join categoria "
				+ " on produto.id_categoria = categoria.idcategoria where nome like ?"; 
		stmt = con.prepareStatement(sql);
		stmt.setString(1, nomeFuncionario+"%");
		
		//Objeto que recebe a lista completa do stmt, para sele��o dos dados		
		rs = stmt.executeQuery();
		List<Funcionario> lista = new ArrayList<Funcionario>();
		
		while(rs.next()) {
			Funcionrio funcionario = new Funcionario(rs.getInt("idFuncionario"),
										  rs.getString("nome"),
										  rs.getInt("CPF"),
										  rs.getString("endere�o"),
										  rs.getString("telefone"),
										  rs.getDouble("preco"),
										  rs.getDate("dataadmiss�o"));
			Cargo cargo = new Cargo(rs.getInt("idcargo"), 
												rs.getString("nomeCargo"));
			funcionario.setCargo(cargo);
			
			lista.add(funcionario);
		}
		
		close();
		return lista;
	}
	public Funcionario buscarFuncionarioPorId(int idFuncionario) throws SQLException {
		open();
		String sql = "select * from funcionario inner join cargo "
				+ " on id_cargo = idcargo where idFuncionario = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idFuncionario);
		
		Funcionario funcionario = null;
		rs = stmt.executeQuery();
		
		if(rs.next()) {
			funcionario = new Funcionario(rs.getInt("idFuncionario"),
					  rs.getString("nome"),
					  rs.getInt("CPF"),
					  rs.getString("endere�o"),
					  rs.getString("telefone"),
					  rs.getDouble("preco"),
					  rs.getDate("dataadmiss�o"));
			
			Cargo cargo = new Cargo(rs.getInt("idCargo"), 
												rs.getString("nomeCategoria"));
			produto.setCategoria(categoria);
		}
		close();
		return produto;
	}

}
