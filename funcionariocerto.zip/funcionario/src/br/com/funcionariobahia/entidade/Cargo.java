package br.com.funcionariobahia.entidade;

public class Cargo {

}
