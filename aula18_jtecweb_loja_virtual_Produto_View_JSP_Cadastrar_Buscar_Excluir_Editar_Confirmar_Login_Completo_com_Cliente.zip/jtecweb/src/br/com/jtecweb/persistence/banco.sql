CREATE DATABASE jtecweb;

USE jtecweb;

create table contato(
	id BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255),
    email VARCHAR(255),
    endereco VARCHAR(255)
);