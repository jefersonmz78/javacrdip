package br.com.jtecweb.execucao;

import java.sql.SQLException;

import br.com.jtecweb.entidade.Contato;
import br.com.jtecweb.persistence.ContatoDao;

public class InsereContatoDao {
	
	public static void main(String[] args) throws SQLException {
		
		//Instanciando um Objeto
		Contato contato = new Contato();
		
		//Atribuindo os valores do Objeto �s vari�veis
		String nome = "Jos� Valad�o";
		String email = "jj.olliver@gmail.com";
		String endereco = "Duque de Caxias";
		
		//Passando os valores das vari�veis para o m�todo set da 
		//Classe Modelo Contato
		contato.setNome(nome);
		contato.setEmail(email);
		contato.setEndereco(endereco);
		
		//Instanciando um Objeto do tipo ContatoDao
		ContatoDao dao = new ContatoDao();
		dao.adicionaContato(contato);
		
		System.out.println("Contato "+contato.getNome()+" adicionado com sucesso!!!");
		
	}

}
