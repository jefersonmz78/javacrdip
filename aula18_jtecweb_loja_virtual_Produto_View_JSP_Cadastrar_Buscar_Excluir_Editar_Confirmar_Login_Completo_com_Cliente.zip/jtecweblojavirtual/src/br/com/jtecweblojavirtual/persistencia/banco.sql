create database lojavirtual;

use lojavirtual;

create table categoria(
	idcategoria int primary key auto_increment,
	nomecategoria varchar(15)
);

create table produto(
	idproduto int primary key auto_increment,
	nomeProduto varchar(20) not null,
	estoque int not null,
	preco double(10,2) not null,
	validade date not null,
	id_categoria int
);

create table admin(
 	idAdmin int primary key auto_increment,
 	nome varchar(50),
 	login varchar(50) unique,
 	senha varchar(15)
);

CREATE TABLE cliente (
idcliente BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(50),
email VARCHAR(50) UNIQUE,
login VARCHAR(50) UNIQUE,
senha VARCHAR(50),
cpf VARCHAR(50) UNIQUE
);

alter table produto add constraint fkprodutocategoria 
	foreign key(id_categoria) references categoria(idcategoria);
	
insert into categoria values(null, 'Livros');
insert into categoria values(null, 'Informatica');
insert into categoria values(null, 'Eletronico');
insert into categoria values(null, 'Roupas');
insert into categoria values(null, 'Jogos');
insert into categoria values(null, 'DVD');


select * from categoria;
