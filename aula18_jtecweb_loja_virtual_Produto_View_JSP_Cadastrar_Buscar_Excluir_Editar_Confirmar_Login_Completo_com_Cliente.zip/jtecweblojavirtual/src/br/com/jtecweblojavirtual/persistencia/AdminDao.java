package br.com.jtecweblojavirtual.persistencia;

import java.sql.SQLException;

import br.com.jtecweblojavirtual.entidade.Admin;

public class AdminDao extends Dao {
	
	public Admin consultarLoginSenha(String login, String senha) throws SQLException, ClassNotFoundException{
		open();
		String sql = "select * from admin where login = ? and senha = ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, login);
		stmt.setString(2, senha);
		
		rs = stmt.executeQuery();
		
		Admin admin = null;
		
		if(rs.next()){
			admin = new Admin(rs.getString("login"), 
							  rs.getString("senha"));			
		}
		close();
		return admin;
	}
}
