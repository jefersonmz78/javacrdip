package br.com.jtecweblojavirtual.persistencia;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.jtecweblojavirtual.entidade.Cliente;
import br.com.jtecweblojavirtual.entidade.Login;

public class ClienteDao extends Dao {

	public Login login(String login, String senha) throws SQLException, ClassNotFoundException {
		open();
		String sql = "SELECT login, senha FROM cliente WHERE login = ? AND senha = ?";
		stmt = con.prepareStatement(sql);

		stmt.setString(1, login);
		stmt.setString(2, senha);

		rs = stmt.executeQuery();
		Login log = null;

		if (rs.next()) {
			log = new Login(rs.getString(1), rs.getString(2));
		}
		close();
		return log;
	}

	public void adicionar(Cliente cliente) throws ClassNotFoundException {
		String sql = "insert into cliente " + "(nome,email,login,senha,cpf)" + " values (?,?,?,?,?)";

		try {
			// prepared statement para inser��o
			open();
			stmt = con.prepareStatement(sql);

			// seta os valores
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getEmail());
			stmt.setString(3, cliente.getLogin());
			stmt.setString(4, cliente.getSenha());
			stmt.setString(5, cliente.getCpf());

			// executa
			stmt.execute();
			close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void editar(Cliente cliente) throws ClassNotFoundException {
		String sql = "update cliente set nome=?, email=?, login=?, senha=?, cpf=? where idCliente=?";

		try {
			open();
			stmt = con.prepareStatement(sql);
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getEmail());
			stmt.setString(3, cliente.getLogin());
			stmt.setString(4, cliente.getSenha());
			stmt.setString(5, cliente.getCpf());
			stmt.setLong(6, cliente.getIdCliente());

			stmt.execute();
			close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void excluir(Cliente cliente) throws ClassNotFoundException {

		try {
			open();
			stmt = con.prepareStatement("delete from cliente where idCliente=?");
			stmt.setLong(1, cliente.getIdCliente());
			stmt.execute();
			close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Cliente> listarCliente(String nome) throws ClassNotFoundException, SQLException {

		open();

		stmt = this.con.prepareStatement("select * from cliente where nome like ?");
		stmt.setString(1, nome + "%");

		rs = stmt.executeQuery();
		List<Cliente> clientes = new ArrayList<Cliente>();

		while (rs.next()) {
			// criando o objeto Cliente
			Cliente cliente = new Cliente();
			cliente.setIdCliente(rs.getLong("idCliente"));
			cliente.setNome(rs.getString("nome"));
			cliente.setEmail(rs.getString("email"));
			cliente.setLogin(rs.getString("login"));
			cliente.setSenha(rs.getString("senha"));
			cliente.setCpf(rs.getString("cpf"));

			// adicionando o objeto � lista
			clientes.add(cliente);
		}
		close();
		return clientes;

	}

	public Cliente buscarCliente(String login) throws SQLException, ClassNotFoundException {

		open();
		String sql = "SELECT * FROM cliente WHERE login  = ?";
		stmt = con.prepareStatement(sql);
		stmt.setString(1, login);
		Cliente cliente = null;
		rs = stmt.executeQuery();

		if (rs.next()) {
			cliente = new Cliente(rs.getLong("idCliente"), rs.getString("nome"), rs.getString("email"),
					rs.getString("login"), rs.getString("senha"), rs.getString("cpf"));
		}
		close();
		return cliente;

	}

	public Cliente buscarPorIdCliente(int idCliente) throws ClassNotFoundException, SQLException {
		open();
		String sql = "select * from cliente where idcliente = ?";
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, idCliente);

		Cliente cliente = null;
		rs = stmt.executeQuery();

		if (rs.next()) {
			cliente = new Cliente(rs.getLong("idCliente"), rs.getString("nome"), rs.getString("email"),
					rs.getString("login"), rs.getString("senha"), rs.getString("cpf"));
		}
		close();
		return cliente;
	}
}